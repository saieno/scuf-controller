# scuf-vantage2
SystemD Script to Enable Native Support for SCUF Vantage 2 Controller
